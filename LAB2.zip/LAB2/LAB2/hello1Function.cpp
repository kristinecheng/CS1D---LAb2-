#include<iostream>
using namespace std;

int hello1Function(string name1)
{
	cout << "hello World" << name1 << endl;
	return 0;
}